#!/bin/bash

# To create an S3 bucket use the `aws s3 mb` command: `aws s3 mb s3://_______` replacing the blank with the name of your bucket. 

aws s3 mb s3://seans-data-lakehouse