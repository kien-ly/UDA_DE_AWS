# Spark Essentials Exercises

You will notice a `requirements.txt` file that has your spark dependencies for this lesson.

Also, there is a `data` directory containing a `sparkify_log_small.json` file. This log file represents user data from a music streaming website, and is used in most of the exercises.